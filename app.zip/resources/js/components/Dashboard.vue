<template>
    <div class="container-fluid">
	<div class="row">
		<div class="col-md-10">	
			<br><br>
			<p>
				<span>Liebe Moderatoren,</span>
			</p>
			<p>
				<span>auf der Adminansicht könnt ihr die folgenden wichtigen Aufgaben erledigen:</span>
			</p>
			<p>
				<span><strong><u>Benutzer-Managment</u></strong></span>
			</p>
			<p>
				<span>A) Neue Benutzer freischalten:</span>
			</p>
			<p>
				<em>Benutzer</em> <span>-&gt; Name des Studierenden auswählen und diesen mit einem Ausweis bzw. dessen Kreuzmich-Konto auf Richtigkeit prüfen -&gt; auf das Häkchen-Symbol klicken und bestätigen.</span>
			</p>
			<p>
				<span>B) Benutzer Modus von "Protokoll Abgeben" zu "Protokoll runterladen" wechseln.</span><span>Es kann mal passieren, dass ein Benutzer das falsche Protokoll runtergeladen hat oder es eventuell ein Problem mit der Seite gibt. In diesem Fall wäre es schlecht, wenn er oder sie einfach Mist ins Protokoll schreibt, um sich für weitere Protokolle freizuschalten. Ihr könnt dem Benutzer den Zugang auf "Protokoll runterladen" wieder freigeben, unter</span>
			</p>
			<p>
				<em>Protokolle-Managment -&gt; Empfangene Protokolle</em> <span>-&gt; aktuellstes Ergbenis des Benutzers finden -&gt; auf Schloss-Symbol klicken und bestätigen.</span>
			</p>
			
			<p>
				<span><strong><u>Protokolle-Managment</u></strong></span>
			</p>
			<p>
				<span>A) Protokolle Hochladen<br> Dieser Abschnitt ist leider nicht ganz intuitiv. Bitte die Schritte in dieser Reihenfolge folgen:</span>
			</p>
			<p>
				<span>1.</span> Wenn der Prüfer noch nicht angelegt worden ist: <em>Protokolle-Managment</em> <span>-&gt;</span> <em>Prüfer</em> <span>-&gt;</span> <em>Prüfer anlegen</em> <span>("Nachname, Vorname" und Fach).</span>
			</p>
			<p>
				<span>2. </span><em>Protokolle-Managment</em> <span>-&gt;</span> <em>Prüfung</em> <span>-&gt; richtige Prüfung in der Liste finden -&gt; auf Pfeil-Symbol klicken -&gt; Prüfername von der Liste aussuchen &amp; Datei vom Computer hochladen.</span>
			</p>
			<p>
				<span>3. Die Datei kann man dann sehen (und bei Fehlern ggf. löschen) unter</span> <em>Verknüpfte Prüfer-Prüfung.</em>
			</p>
			<p>
				<span>B) Benutzer-Kommentare für Beleidigungen oder Verbotenes kontrollieren</span> <em>Protokolle-Managment</em> <span>-&gt;</span> <em>Empfangene Protokolle</em> <span>-&gt; Benutzer finden -&gt; auf "i"-Symbol klicken -&gt; gegebenfalls Informationen weitergeben (besonders bei Drohungen, sexuellen oder verfassungsfeindlichen Inhalten) oder selber mit dem Studierenden schimpfen :P</span>
			</p>
			
			<p>
				<span><strong><u>Skripte hochladen</u></strong></span>
			</p>
			<p>
				<em>Skript Hochladen</em> <span>-&gt;</span> <em>Neues Skript hinzufügen</em> <span>klicken -&gt; Informationen ausfüllen und bestätigen.</span>
			</p>
			
			<p>
				<span><strong><u>Erinnerungs-E-Mails</u></strong></span>
			</p>
			<p>
				<span>Es ist sehr wichtig, dass ihr jedes Semester die Prüfungstermine aktualisiert! Nur so werden die Studierende ihre Erinnerungs-E-mails zum relevanten Zeitpunkt bekommen.<br>Die andere Einstellungen könntet ihr (vermutlich) so lassen, wie sie sind.</span>
			</p>
			
			<p>
				<em>Erinnerungs-E-Mails</em> <span>-&gt;</span> <em>Aktualisieren klicken</em> <span>-&gt;</span> <em>Zeitspanne ändern</em>
			</p>
			
			<br>
			<p>
				<span>Falls es Probleme gibt oder ihr Vorschläge habt, könnt ihr euch jederzeit bei mir melden!</span><span><br><a href="mailto:omerreiner@gmail.com ">omerreiner@gmail.com</a></span>
			</p>
			<p>
				<span>Vielen Dank und viel Erfolg!</span>
			</p>
		</div>
		<div class="col-md-2">
		</div>
	</div>
</div>
</template>

<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        }
    }
</script>
