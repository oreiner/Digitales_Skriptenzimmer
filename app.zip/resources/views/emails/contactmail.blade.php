@component('mail::message')
# Hallo,

Das ist ein Test vom Kontaktform!<br>

Beste Grüße<br>
Dein Skriptenzimmer-Team
@endcomponent