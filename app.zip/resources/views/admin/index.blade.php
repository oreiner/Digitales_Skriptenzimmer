@extends('admin.layouts.app')

@section('title',' Dashboard')
@section('head')

        <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
        <meta charset="utf-8">
        <title>Waypoints in directions</title>


    @endsection
@section('content')
    <div class="container-fluid">
    <div class="navbar navbar-default" style="background-color: cornflowerblue; margin-top: 2%">
dfs asdf asdf asdf asdf asdf asfd
    </div>
    </div>




    {{--<!-- firebase configuration -->--}}
    {{--<script src="https://www.gstatic.com/firebasejs/4.1.2/firebase.js"></script>--}}
    {{--<script>--}}
        {{--// Initialize Firebase--}}
        {{--var config = {--}}
            {{--apiKey: "AIzaSyC3cSJFszxEuUu6SgMgCJTJBkGOuGV0CBE",--}}
            {{--authDomain: "drop-bag.firebaseapp.com",--}}
            {{--databaseURL: "https://drop-bag.firebaseio.com",--}}
            {{--projectId: "drop-bag",--}}
            {{--storageBucket: "drop-bag.appspot.com",--}}
            {{--messagingSenderId: "453208184366"--}}
        {{--};--}}
        {{--firebase.initializeApp(config);--}}
    {{--</script>--}}
@endsection
@section('footer')

@endsection